"""Local-only P&T AI SQUARE integration. It never connects to MongoDB."""
__version__ = '1.1.0'
